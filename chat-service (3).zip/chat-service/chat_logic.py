def generate_response(message: str) -> str:
    # TODO: Replace with real LLM later
    return f"Echo: {message}"